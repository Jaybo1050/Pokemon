
public class Trainer extends Card {
	
	private String name;

    public Trainer(String name) {
        this.name = name;
    }
    
}
