
public class FireEnergy extends Energy {
	
	public FireEnergy() {
        super("Fire");
    }

}
