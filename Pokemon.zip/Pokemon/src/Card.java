
public class Card {
	
	protected String type; 

    public String getType() {
        return type;
    }

}
