
public class Charmander extends Pokemon{
	

	public Charmander() {
		super("Fire");
		setHP(60);
		setDmg(30);
	}
	
}
