
public class Tester {

	public static void main(String[] args) {
		CardGame game = new CardGame();  
        game.startGame();
    }

}
