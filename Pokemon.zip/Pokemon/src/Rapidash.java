
public class Rapidash extends Pokemon {
	
    public Rapidash() {
    	super("Fire");
        setHP(100);
        setDmg(60);
    }
}