
public class Heatmor extends Pokemon{
	
	public Heatmor() {
		super("Fire");
		setHP(120);
		setDmg(20);
	}
}
