
public class Energy extends Card{
	
	private String type;

    public Energy(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }
    
}
