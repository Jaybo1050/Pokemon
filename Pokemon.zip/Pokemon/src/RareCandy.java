
public class RareCandy extends Trainer {
	public RareCandy() {
        super("Rare Candy");
    }
}
