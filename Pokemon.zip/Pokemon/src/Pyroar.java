
public class Pyroar extends Pokemon {
	
	public Pyroar() {
		super("Fire");
		setHP(110);
		setDmg(60);
	}

}
