
public class Crocalor extends Pokemon {
	
	public Crocalor() {
		super("Fire");
		setHP(100);
		setDmg(50);
	}
}
